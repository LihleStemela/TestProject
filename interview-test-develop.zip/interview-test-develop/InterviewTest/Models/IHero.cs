﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InterviewTest.Models
{
    interface IHero
    {
        int evolve();
        //void evolve();
    }
}
